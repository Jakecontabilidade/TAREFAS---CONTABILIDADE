'use client';
import KanbanTarefasEmpresas from './KanbanTarefasEmpresas';

export default function Home() {
  return <KanbanTarefasEmpresas />;
}